   /* 
 * File:   Minimum or Maximum    
 * Author: Bryan Puga
 * Created on September 29, 2017, 9:47 PM
 * Purpose:  This program will tell you which number is bigger.
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    short a;
    short b;
    
    cout<<"Input Two Numbers"<<endl;
    cout<<"The Program will tell you which number is bigger"<<endl;
    cin>>a;
    cin>>b;
    
    //Input or initialize values Here
    if(a>b){
        a = a;
        b = b;
    }
    else{
        a = a^b;
        b = a^b;
        a = a^b;
    }
    
    cout<<a<<" Is Bigger than "<<b<<endl;
    
    //Process/Calculations Here
   
    return 0;
}

