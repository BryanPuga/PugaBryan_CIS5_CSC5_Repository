   /* 
 * File:Mass Personal Best
 * Author: Bryan Puga
 * Created on September 29, 2017, 12:59 AM
 * Purpose:  This program will get a runners name and his best times
 */

//System Libraries Here
#include <iostream>
#include <string>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    string R1; //pole vaulter name
   
    
    float R1T; //Time 1
    float R2T; //Time 2
    float R3T; //Time 3
    
    string date1;
    string date2;
    string date3;
    
    float first_place;
    float second_place;
    float third_place;
    
    
    cout<<"Enter the name of the Pole Vaulter"<<endl;
    cin>>R1;
    cout<<"Enter Hight (Meters) of 3 best pole vaults"<<endl;
    
    cout<<"Enter first Pole vault"<<endl;
    cin>>R1T;
    cout<<"Date of vault"<<endl;
    cin>>date1;
    
    cout<<"Enter Second Pole vault"<<endl;
    cin>>R2T;
    cout<<"Date of vault"<<endl;
    cin>>date2; 
    
    cout<<"Enter Third Pole vault"<<endl;
    cin>>R3T;
    cout<<"Date of vault"<<endl;
    cin>>date3;
    
    
    
    
    
    
    
    if(R1T<2|| R2T <2 || R3T<2 ||R1T>5|| R2T >5 || R3T>5 ){
        cout<<"Invalid Height"<<endl;
    }
    else{
       
     if (R1T > R2T && R1T > R2T){ //runner 1 wins
        first_place = R1T;
        if(R2T > R3T){          //runner 1 1st , runner 2 2nd, runner 3 3rd
            second_place = R2T;
            third_place = R3T;
            cout<<"Best Time: "<<R1T<<", Date: "<<date1<<endl;
            cout<<"Second Best Time: "<<R2T<<", Date: "<<date2<<endl;
            cout<<"Third Best Time: "<<R3T<<", Date: "<<date3<<endl;
        }
        else{                  //runner 1 1st, runner 3 2nd, runner 2 3rd
            second_place = R3T;
            third_place = R2T;
            cout<<"Best Time: "<<R1T<<", Date: "<<date1<<endl;
            cout<<"Second Best Time: "<<R3T<<", Date: "<<date3<<endl;
            cout<<"Third Best Time: "<<R2T<<", Date: "<<date2<<endl;
            
        }
    }
    else if(R2T > R1T && R2T > R3T){ //runner 2 1st
        first_place = R2T;
        if(R1T > R3T){             //runner 2 1st, runner 1 2nd, runner 3 3rd
            second_place = R1T;
            third_place = R3T;
            cout<<"Best Time: "<<R2T<<", Date "<<date2<<endl;
            cout<<"Second Best Time: "<<R1T<<", Date: "<<date1<<endl;
            cout<<"Third Best Time: "<<R3T<<", Date: "<<date3<<endl;
        }
         else{                      //runner 2 1st, runner 3 2nd, runner 2 3rd
            second_place = R3T;
            third_place = R1T;
            cout<<"Best Time: "<<R2T<<", Date: "<<date2<<endl;
            cout<<"Second Best Time: "<<R3T<<", Date: "<<date3<<endl;
            cout<<"Third Best Time: "<<R1T<<", Date: "<<date1<<endl;
        }  
    }
    else{
        first_place = R3T;       //runner 3 wins
        if(R1T > R2T){          //runner 3 1st, runner  1 2nd, runner 2 3rd
            second_place = R1T;
            third_place = R2T;
            cout<<"Best Time: "<<R3T<<", Date: "<<date3<<endl;
            cout<<"Second Best Time: "<<R1T<<", Date: "<<date1<<endl;
            cout<<"Third Best Time: "<<R2T<<", Date: "<<date2<<endl;
        }
        else{                   // runner 3 1st, runner 2 2nd, runner 1 3rd
            second_place = R2T;
            third_place = R1T;
            cout<<"Best Time: "<<R3T<<", Date: "<<date3<<endl;
            cout<<"Second Best Time: "<<R2T<<", Date: "<<date2<<endl;
            cout<<"Third Best Time: "<<R1T<<", Date: "<<date1<<endl;
        }  
    }
    }
    
    return 0;
}

