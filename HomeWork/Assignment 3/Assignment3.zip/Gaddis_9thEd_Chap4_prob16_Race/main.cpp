   /* 
 * File:Mass Race 
 * Author: Bryan Puga
 * Created on September 29, 2017, 11:26 PM
 * Purpose:  This program will get 3 runners and their time and see who won
 */

//System Libraries Here
#include <iostream>
#include <string>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    string R1; //runner 1 name
    string R2; // runner 2 name
    string R3; //runner 3 name
    
    short R1T; //runner 1 time
    short R2T; //runner 2 time
    short R3T; //runner 3 time
    
    string first_place;
    string second_place;
    string third_place;
    
    cout<<"This program will get the name of 3 runners and their time and tell who won"<<endl;
    cout<<"Enter the names of the Runners"<<endl;
    cin>>R1;
    cin>>R2;
    cin>>R3;
    
    cout<<"Enter "<<R1<<" Time"<<endl;
    cin>>R1T;
    cout<<"Enter "<<R2<<" Time"<<endl;
    cin>>R2T;
    cout<<"Enter "<<R3<<" Time"<<endl;
    cin>>R3T;
    if(R1T<0 || R2T <0 || R3T<0){
        cout<<"That an invalid time no negative time"<<endl;
    }
    else{
       
     if (R1T < R2T && R1T < R2T){ //runner 1 wins
        first_place = R1;
        if(R2T < R3T){          //runner 1 1st , runner 2 2nd, runner 3 3rd
            second_place = R2;
            third_place = R3;
            cout<<R1<<" First place, "<<R2<<" Second Place, "<<R3<<" Third Place"<<endl;
        }
        else{                  //runner 1 1st, runner 3 2nd, runner 2 3rd
            second_place = R3;
            third_place = R2;
            cout<<R1<<" First place, "<<R3<<" Second Place, "<<R2<<" Third Place"<<endl;
        }
    }
    else if(R2T < R1T && R2T < R3T){ //runner 2 1st
        first_place = R2;
        if(R1T < R3T){             //runner 2 1st, runner 1 2nd, runner 3 3rd
            second_place = R1;
            third_place = R3;
            cout<<R2<<" First place, "<<R1<<" Second Place, "<<R3<<" Third Place"<<endl;
        }
         else{                      //runner 2 1st, runner 3 2nd, runner 2 3rd
            second_place = R3T;
            third_place = R1T;
            cout<<R2<<" First place, "<<R3<<" Second Place, "<<R1<<" Third Place"<<endl;
        }  
    }
    else{
        first_place = R3;       //runner 3 wins
        if(R1T < R2T){          //runner 3 1st, runner  1 2nd, runner 2 3rd
            second_place = R1;
            third_place = R2;
            cout<<R3<<" First place, "<<R1<<" Second Place, "<<R2<<" Third Place"<<endl;
        }
        else{                   // runner 3 1st, runner 2 2nd, runner 1 3rd
            second_place = R2;
            third_place = R1;
            cout<<R3<<" First place, "<<R2<<" Second Place, "<<R1<<" Third Place"<<endl;
        }  
    }
    }
    
    return 0;
}

