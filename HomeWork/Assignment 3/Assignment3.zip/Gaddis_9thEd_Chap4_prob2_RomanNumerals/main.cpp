   /* 
 * File:   Roman Numerals   
 * Author: Bryan Puga
 * Created on September 29, 2017, 10:00 PM
 * Purpose:  This program will convert numbers 1-10 to Roman Numerals
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int n;
    
    
    
    cout<<"The Program will Convert a Number from 1 - 10 Into their Roman Numeral counter part"<<endl;
            
    
    cin>>n;
   
    
    //Input or initialize values Here
    
    if (n == 1){
        cout<<n<<" In Roman Numeral is I";
    }
    else if (n == 2){
        cout<<n<<" In Roman Numeral is II";
    }
    else if (n == 3){
        cout<<n<<" In Roman Numeral is III";
    }
    else if (n == 4){
        cout<<n<<" In Roman Numeral is IV";
    }
    else if (n == 5){
        cout<<n<<" In Roman Numeral is V";
    }
    else if (n == 6){
        cout<<n<<" In Roman Numeral is VI";
    }
    else if (n == 7){
        cout<<n<<" In Roman Numeral is VII";
    }
    else if (n == 8){
        cout<<n<<" In Roman Numeral is VIII";
    }
    else if (n == 9){
        cout<<n<<" In Roman Numeral is IX";
    }
    else if (n == 10){
        cout<<n<<" In Roman Numeral is X";
    }
    else{
        cout<<"The Number you input in not within acceptable bounds choose a number from 1-10"<<endl;
                
    }
    
    
    
    //Process/Calculations Here
   
    return 0;
}

