   /* 
 * File:All in one
 * Author: Bryan Puga
 * Created on October 1, 2017, 10:53AM
 * Purpose:  Merge all over codes into one program
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    
    int a;
    
    cout<<"Which program would you like to use?"<<endl;
    cout<<"Pick the number of the program you would like to use."<<endl;
    cout<<"1. Gaddis_9thEd_Chap9_prob1_MinOrMax"<<endl;
    cout<<"2. Gaddis_9thEd_Chap9_prob16_Race"<<endl;
    cout<<"3. Gaddis_9thEd_Chap9_prob17_PersonalBest"<<endl;
   cout<<"4. Gaddis_9thEd_Chap9_prob2_RomanNumerals"<<endl;
   cout<<"5. Gaddis_9thEd_Chap9_prob27_WifiDiagnostic"<<endl;
   cout<<"6. Gaddis_9thEd_Chap9_prob3_MagicDate"<<endl;
   cout<<"7. Gaddis_9thEd_Chap9_prob4_TriangleSize"<<endl;
   cout<<"8. Gaddis_9thEd_Chap9_prob5_BMI"<<endl;
   cout<<"9. Gaddis_9thEd_Chap9_prob6_MassCalculator"<<endl;
   
   cin>>a;
   
   if(a == 1){
       short a;
    short b;
    
    cout<<"Input Two Numbers"<<endl;
    cout<<"The Program will tell you which number is bigger"<<endl;
    cin>>a;
    cin>>b;
    
    //Input or initialize values Here
    if(a>b){
        a = a;
        b = b;
    }
    else{
        a = a^b;
        b = a^b;
        a = a^b;
    }
    
    cout<<a<<" Is Bigger than "<<b<<endl;
   }
   else if(a == 2){
        string R1; //runner 1 name
    string R2; // runner 2 name
    string R3; //runner 3 name
    
    short R1T; //runner 1 time
    short R2T; //runner 2 time
    short R3T; //runner 3 time
    
    string first_place;
    string second_place;
    string third_place;
    
    cout<<"This program will get the name of 3 runners and their time and tell who won"<<endl;
    cout<<"Enter the names of the Runners"<<endl;
    cin>>R1;
    cin>>R2;
    cin>>R3;
    
    cout<<"Enter "<<R1<<" Time"<<endl;
    cin>>R1T;
    cout<<"Enter "<<R2<<" Time"<<endl;
    cin>>R2T;
    cout<<"Enter "<<R3<<" Time"<<endl;
    cin>>R3T;
    if(R1T<0 || R2T <0 || R3T<0){
        cout<<"That an invalid time no negative time"<<endl;
    }
    else{
       
     if (R1T < R2T && R1T < R2T){ //runner 1 wins
        first_place = R1;
        if(R2T < R3T){          //runner 1 1st , runner 2 2nd, runner 3 3rd
            second_place = R2;
            third_place = R3;
            cout<<R1<<" First place, "<<R2<<" Second Place, "<<R3<<" Third Place"<<endl;
        }
        else{                  //runner 1 1st, runner 3 2nd, runner 2 3rd
            second_place = R3;
            third_place = R2;
            cout<<R1<<" First place, "<<R3<<" Second Place, "<<R2<<" Third Place"<<endl;
        }
    }
    else if(R2T < R1T && R2T < R3T){ //runner 2 1st
        first_place = R2;
        if(R1T < R3T){             //runner 2 1st, runner 1 2nd, runner 3 3rd
            second_place = R1;
            third_place = R3;
            cout<<R2<<" First place, "<<R1<<" Second Place, "<<R3<<" Third Place"<<endl;
        }
         else{                      //runner 2 1st, runner 3 2nd, runner 2 3rd
            second_place = R3T;
            third_place = R1T;
            cout<<R2<<" First place, "<<R3<<" Second Place, "<<R1<<" Third Place"<<endl;
        }  
    }
    else{
        first_place = R3;       //runner 3 wins
        if(R1T < R2T){          //runner 3 1st, runner  1 2nd, runner 2 3rd
            second_place = R1;
            third_place = R2;
            cout<<R3<<" First place, "<<R1<<" Second Place, "<<R2<<" Third Place"<<endl;
        }
        else{                   // runner 3 1st, runner 2 2nd, runner 1 3rd
            second_place = R2;
            third_place = R1;
            cout<<R3<<" First place, "<<R2<<" Second Place, "<<R1<<" Third Place"<<endl;
        }  
    }
    }
   }
   else if (a == 3){
        string R1; //pole vaulter name
   
    
    float R1T; //Time 1
    float R2T; //Time 2
    float R3T; //Time 3
    
    string date1;
    string date2;
    string date3;
    
    float first_place;
    float second_place;
    float third_place;
    
    
    cout<<"Enter the name of the Pole Vaulter"<<endl;
    cin>>R1;
    cout<<"Enter Hight (Meters) of 3 best pole vaults"<<endl;
    
    cout<<"Enter first Pole vault"<<endl;
    cin>>R1T;
    cout<<"Date of vault"<<endl;
    cin>>date1;
    
    cout<<"Enter Second Pole vault"<<endl;
    cin>>R2T;
    cout<<"Date of vault"<<endl;
    cin>>date2; 
    
    cout<<"Enter Third Pole vault"<<endl;
    cin>>R3T;
    cout<<"Date of vault"<<endl;
    cin>>date3;
    
    
    
    
    
    
    
    if(R1T<2|| R2T <2 || R3T<2 ||R1T>5|| R2T >5 || R3T>5 ){
        cout<<"Invalid Height"<<endl;
    }
    else{
       
     if (R1T > R2T && R1T > R2T){ //runner 1 wins
        first_place = R1T;
        if(R2T > R3T){          //runner 1 1st , runner 2 2nd, runner 3 3rd
            second_place = R2T;
            third_place = R3T;
            cout<<"Best Time: "<<R1T<<", Date: "<<date1<<endl;
            cout<<"Second Best Time: "<<R2T<<", Date: "<<date2<<endl;
            cout<<"Third Best Time: "<<R3T<<", Date: "<<date3<<endl;
        }
        else{                  //runner 1 1st, runner 3 2nd, runner 2 3rd
            second_place = R3T;
            third_place = R2T;
            cout<<"Best Time: "<<R1T<<", Date: "<<date1<<endl;
            cout<<"Second Best Time: "<<R3T<<", Date: "<<date3<<endl;
            cout<<"Third Best Time: "<<R2T<<", Date: "<<date2<<endl;
            
        }
    }
    else if(R2T > R1T && R2T > R3T){ //runner 2 1st
        first_place = R2T;
        if(R1T > R3T){             //runner 2 1st, runner 1 2nd, runner 3 3rd
            second_place = R1T;
            third_place = R3T;
            cout<<"Best Time: "<<R2T<<", Date "<<date2<<endl;
            cout<<"Second Best Time: "<<R1T<<", Date: "<<date1<<endl;
            cout<<"Third Best Time: "<<R3T<<", Date: "<<date3<<endl;
        }
         else{                      //runner 2 1st, runner 3 2nd, runner 2 3rd
            second_place = R3T;
            third_place = R1T;
            cout<<"Best Time: "<<R2T<<", Date: "<<date2<<endl;
            cout<<"Second Best Time: "<<R3T<<", Date: "<<date3<<endl;
            cout<<"Third Best Time: "<<R1T<<", Date: "<<date1<<endl;
        }  
    }
    else{
        first_place = R3T;       //runner 3 wins
        if(R1T > R2T){          //runner 3 1st, runner  1 2nd, runner 2 3rd
            second_place = R1T;
            third_place = R2T;
            cout<<"Best Time: "<<R3T<<", Date: "<<date3<<endl;
            cout<<"Second Best Time: "<<R1T<<", Date: "<<date1<<endl;
            cout<<"Third Best Time: "<<R2T<<", Date: "<<date2<<endl;
        }
        else{                   // runner 3 1st, runner 2 2nd, runner 1 3rd
            second_place = R2T;
            third_place = R1T;
            cout<<"Best Time: "<<R3T<<", Date: "<<date3<<endl;
            cout<<"Second Best Time: "<<R2T<<", Date: "<<date2<<endl;
            cout<<"Third Best Time: "<<R1T<<", Date: "<<date1<<endl;
        }  
    }
    }
   }
   else if(a==4){
       int n;
    
    
    
    cout<<"The Program will Convert a Number from 1 - 10 Into their Roman Numeral counter part"<<endl;
            
    
    cin>>n;
   
    
    //Input or initialize values Here
    
    if (n == 1){
        cout<<n<<" In Roman Numeral is I";
    }
    else if (n == 2){
        cout<<n<<" In Roman Numeral is II";
    }
    else if (n == 3){
        cout<<n<<" In Roman Numeral is III";
    }
    else if (n == 4){
        cout<<n<<" In Roman Numeral is IV";
    }
    else if (n == 5){
        cout<<n<<" In Roman Numeral is V";
    }
    else if (n == 6){
        cout<<n<<" In Roman Numeral is VI";
    }
    else if (n == 7){
        cout<<n<<" In Roman Numeral is VII";
    }
    else if (n == 8){
        cout<<n<<" In Roman Numeral is VIII";
    }
    else if (n == 9){
        cout<<n<<" In Roman Numeral is IX";
    }
    else if (n == 10){
        cout<<n<<" In Roman Numeral is X";
    }
    else{
        cout<<"The Number you input in not within acceptable bounds choose a number from 1-10"<<endl;
                
    }
   }
   else if(a==5){
        string yes = "yes";
    string no = "no";
    string answer;
   
    cout<<"Reboot the computer and try to connect."<<endl;
    cout<<"Did that fix the problem"<<endl;
    cin>>answer;
    if(answer == yes || answer == "Yes"){
        
    }
    else{
        cout<<"reboot your router and try to connect"<<endl;
        cout<<"Did that fix the problem?"<<endl;
        cin>>answer;
        if(answer == yes || answer == "Yes"){
            
        }
        else{
            cout<<"Make sure that the cables between the router and the modem are plugged in firmly"<<endl;
            cout<<"Did that fix the problem?"<<endl;
            cin>>answer;
            if (answer == yes || answer == "Yes"){
                
            }
            else{
                cout<<"Move the router to a new location and try to connect"<<endl;
                cout<<"Did that fix the problem?"<<endl;
                cin>>answer;
                if(answer == yes || answer == "Yes"){
                    
                }
                else{
                    cout<<"Get a new router"<<endl;
                }
            }
        }
    }
   }
   else if (a == 6){
       int day;
    int month;
    int year;
    int md;
    
    cout<<"This program will tell you if the date you input is a Magic Date"<<endl;
    cout<<"A Magic year is when the day and month are equal to the year"<<endl;
    cout<<"Input a day of the month (1 - 31)"<<endl;
    cin>>day;
    cout<<"Input number of a month (1-12)"<<endl;
    cin>>month;
    cout<<"Input the last 2 digits of a year"<<endl;
    cin>>year;
    md = month*day;
    if(year == md){
        cout<<month<<"/"<<day<<"/"<<year<<" is a Magic Year"<<endl;
        
    }
    else{
        cout<<month<<"/"<<day<<"/"<<year<<" is a NOT Magic Year"<<endl;
    }
    
   }
   else if(a==7){
        short tl1;
    short tl2;
    short tw1;
    short tw2;
    short triangle_one;
    short triangle_two;
    
    cout<<"This program will decide which triangle is bigger between 2"<<endl;
    cout<<"Input Length of Triangle one"<<endl;
    cin>>tl1;
    cout<<"Input Width of Triangle one"<<endl;
    cin>>tw1; 
    cout<<"The area for Triangle one is "<<tl1*tw1<<" units"<<endl;
    cout<<"Input Length of Triangle two"<<endl;
    cin>>tl2;
    cout<<"Input Width of Triangle two"<<endl;
    cin>>tw2;
    cout<<"The area for Triangle Two is "<<tl2*tw2<<" units"<<endl;
    
    triangle_one = tl1*tw1;
    triangle_two = tl2*tw2;
    
    
    if(triangle_one > triangle_two){
        cout<<"Triangle one is bigger than Triangle two"<<endl;
        
    }
    else if (triangle_one == triangle_two){
    cout<<"Triangle one is the same size Triangle two"<<endl;
    }
    else{
        cout<<"Triangle two is bigger than Triangle one"<<endl;
    }
   }
   else if (a==8){
        short W;
    short H;
    short BMI;
    
    
    
    cout<<"This Program will tell you your BMI and tell you if your overweight or not"<<endl;
    cout<<"Enter Weight in pounds"<<endl;
    cin>>W;
    cout<<"Enter your height in Inches"<<endl;
    cin>>H;
    
    BMI = (W*703)/(H*H);
    
    if(BMI < 18.5){
        cout<<"Your BMI is "<<BMI<<" , You are Under Weight"<<endl;
    }
    else if(BMI > 25){
        cout<<"Your BMI is "<<BMI<<" , You are Over Weight"<<endl;
    }
    else{
        cout<<"Your BMI is "<<BMI<<" , You are in Optimal Condition"<<endl;
    }
   }
   else if (a==9){
         short W; //weight of object
    short mass; //Mass of the object
     
    cout<<"This Program will calculate weight using mass"<<endl;
    cout<<"Enter Mass (Kilograms)"<<endl;
    cin>>mass;
    
    W = mass*9.8;
    
    if (W > 1000){
        cout<<"Weight is: "<<W<<" To Heavy"<<endl;
    }
    else if(W < 10){
        cout<<"Weight is: "<<W<<" To Light"<<endl;
    }
    else{
        cout<<"Weight is: "<<W<<endl;
    }
   }
   else{
       cout<<"That was not an option please pick a number between 1-9";
   }
    
    
    
    
    
    
    
 
   
    
    
    
   return 0;
}

