   /* 
 * File:Mass Wifi Diagnostic
 * Author: Bryan Puga
 * Created on September 29, 2017, 12:35 AM
 * Purpose:  This program will Help Diagnosing your Wifi
 */

//System Libraries Here
#include <iostream>
#include <string>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    string yes = "yes";
    string no = "no";
    string answer;
   
    cout<<"Reboot the computer and try to connect."<<endl;
    cout<<"Did that fix the problem"<<endl;
    cin>>answer;
    if(answer == yes || answer == "Yes"){
        
    }
    else{
        cout<<"reboot your router and try to connect"<<endl;
        cout<<"Did that fix the problem?"<<endl;
        cin>>answer;
        if(answer == yes || answer == "Yes"){
            
        }
        else{
            cout<<"Make sure that the cables between the router and the modem are plugged in firmly"<<endl;
            cout<<"Did that fix the problem?"<<endl;
            cin>>answer;
            if (answer == yes || answer == "Yes"){
                
            }
            else{
                cout<<"Move the router to a new location and try to connect"<<endl;
                cout<<"Did that fix the problem?"<<endl;
                cin>>answer;
                if(answer == yes || answer == "Yes"){
                    
                }
                else{
                    cout<<"Get a new router"<<endl;
                }
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}

