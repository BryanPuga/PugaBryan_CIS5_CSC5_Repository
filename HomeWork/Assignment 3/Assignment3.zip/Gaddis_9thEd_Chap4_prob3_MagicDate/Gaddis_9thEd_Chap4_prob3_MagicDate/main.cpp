   /* 
 * File:   Magic Date    
 * Author: Bryan Puga
 * Created on September 29, 2017, 10:18 PM
 * Purpose:  This program will tell you which number is bigger.
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int day;
    int month;
    int year;
    int md;
    
    cout<<"This program will tell you if the date you input is a Magic Date"<<endl;
    cout<<"A Magic year is when the day and month are equal to the year"<<endl;
    cout<<"Input a day of the month (1 - 31)"<<endl;
    cin>>day;
    cout<<"Input number of a month (1-12)"<<endl;
    cin>>month;
    cout<<"Input the last 2 digits of a year"<<endl;
    cin>>year;
    md = month*day;
    if(year == md){
        cout<<month<<"/"<<day<<"/"<<year<<" is a Magic Year"<<endl;
        
    }
    else{
        cout<<month<<"/"<<day<<"/"<<year<<" is a NOT Magic Year"<<endl;
    }
    
    
    
   
    return 0;
}

