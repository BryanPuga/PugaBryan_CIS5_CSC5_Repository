   /* 
 * File:   BMI    
 * Author: Bryan Puga
 * Created on September 29, 2017, 10:18 PM
 * Purpose:  This program will Calculate your BMI.
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    short W;
    short H;
    short BMI;
    
    
    
    cout<<"This Program will tell you your BMI and tell you if your overweight or not"<<endl;
    cout<<"Enter Weight in pounds"<<endl;
    cin>>W;
    cout<<"Enter your height in Inches"<<endl;
    cin>>H;
    
    BMI = (W*703)/(H*H);
    
    if(BMI < 18.5){
        cout<<"Your BMI is "<<BMI<<" , You are Under Weight"<<endl;
    }
    else if(BMI > 25){
        cout<<"Your BMI is "<<BMI<<" , You are Over Weight"<<endl;
    }
    else{
        cout<<"Your BMI is "<<BMI<<" , You are in Optimal Condition"<<endl;
    }
   
    return 0;
}

