   /* 
 * File:Mass Calculator  
 * Author: Bryan Puga
 * Created on September 29, 2017, 11:16 PM
 * Purpose:  This program will Calculate weight using mass.
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    short W; //weight of object
    short mass; //Mass of the object
     
    cout<<"This Program will calculate weight using mass"<<endl;
    cout<<"Enter Mass (Kilograms)"<<endl;
    cin>>mass;
    
    W = mass*9.8;
    
    if (W > 1000){
        cout<<"Weight is: "<<W<<" To Heavy"<<endl;
    }
    else if(W < 10){
        cout<<"Weight is: "<<W<<" To Light"<<endl;
    }
    else{
        cout<<"Weight is: "<<W<<endl;
    }
    
    
    
    return 0;
}

