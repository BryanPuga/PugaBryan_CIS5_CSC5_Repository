   /* 
 * File:Triangle Size 
 * Author: Bryan Puga
 * Created on September 29, 2017, 10:34 PM
 * Purpose:  This program will tell you which Triangle is Bigger Between 2.
 */

//System Libraries Here
#include <iostream>

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    short tl1;
    short tl2;
    short tw1;
    short tw2;
    short triangle_one;
    short triangle_two;
    
    cout<<"This program will decide which triangle is bigger between 2"<<endl;
    cout<<"Input Length of Triangle one"<<endl;
    cin>>tl1;
    cout<<"Input Width of Triangle one"<<endl;
    cin>>tw1; 
    cout<<"The area for Triangle one is "<<tl1*tw1<<" units"<<endl;
    cout<<"Input Length of Triangle two"<<endl;
    cin>>tl2;
    cout<<"Input Width of Triangle two"<<endl;
    cin>>tw2;
    cout<<"The area for Triangle Two is "<<tl2*tw2<<" units"<<endl;
    
    triangle_one = tl1*tw1;
    triangle_two = tl2*tw2;
    
    
    if(triangle_one > triangle_two){
        cout<<"Triangle one is bigger than Triangle two"<<endl;
        
    }
    else if (triangle_one == triangle_two){
    cout<<"Triangle one is the same size Triangle two"<<endl;
    }
    else{
        cout<<"Triangle two is bigger than Triangle one"<<endl;
    }
   
    
    return 0;
}

